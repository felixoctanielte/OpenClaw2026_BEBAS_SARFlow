#!/usr/bin/env python3
"""
Generate PDF Laporan Operasi SAR
INS-20260515-006 — 2 Pendaki Hilang Gunung Merbabu
"""

from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm, cm
from reportlab.lib.colors import HexColor, black, white, grey
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT, TA_JUSTIFY
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, HRFlowable, Frame, PageTemplate, BaseDocTemplate
)
from reportlab.lib import colors
from datetime import datetime
import os

# ──────────────────────────────────────────────
# Color palette — SARFlow
# ──────────────────────────────────────────────
NAVY     = HexColor("#1B2A4A")
RED      = HexColor("#C0392B")
DARK_RED = HexColor("#922B21")
ORANGE   = HexColor("#E67E22")
YELLOW   = HexColor("#F39C12")
GREEN    = HexColor("#27AE60")
LIGHT_GREY = HexColor("#ECF0F1")
MED_GREY = HexColor("#95A5A6")
DARK_GREY = HexColor("#2C3E50")

# ──────────────────────────────────────────────
# Styles
# ──────────────────────────────────────────────
styles = getSampleStyleSheet()

styles.add(ParagraphStyle(
    name='CoverTitle', fontName='Helvetica-Bold', fontSize=26,
    leading=32, textColor=white, alignment=TA_CENTER, spaceAfter=6*mm
))
styles.add(ParagraphStyle(
    name='CoverSub', fontName='Helvetica', fontSize=14,
    leading=18, textColor=HexColor("#D5D8DC"), alignment=TA_CENTER, spaceAfter=4*mm
))
styles.add(ParagraphStyle(
    name='CoverInfo', fontName='Helvetica', fontSize=11,
    leading=14, textColor=HexColor("#BDC3C7"), alignment=TA_CENTER
))
styles.add(ParagraphStyle(
    name='SectionTitle', fontName='Helvetica-Bold', fontSize=14,
    leading=18, textColor=NAVY, spaceBefore=6*mm, spaceAfter=3*mm,
    borderWidth=0, borderPadding=0
))
styles.add(ParagraphStyle(
    name='SubTitle', fontName='Helvetica-Bold', fontSize=11,
    leading=14, textColor=DARK_GREY, spaceBefore=3*mm, spaceAfter=2*mm
))
styles.add(ParagraphStyle(
    name='BodyText2', fontName='Helvetica', fontSize=9.5,
    leading=13, textColor=DARK_GREY, spaceAfter=2*mm,
    alignment=TA_JUSTIFY
))
styles.add(ParagraphStyle(
    name='BodySmall', fontName='Helvetica', fontSize=8.5,
    leading=11, textColor=DARK_GREY, spaceAfter=1*mm
))
styles.add(ParagraphStyle(
    name='DisclaimerStyle', fontName='Helvetica-Bold', fontSize=7.5,
    leading=10, textColor=RED, alignment=TA_CENTER, spaceAfter=2*mm
))
styles.add(ParagraphStyle(
    name='FooterStyle', fontName='Helvetica', fontSize=7,
    leading=9, textColor=MED_GREY, alignment=TA_CENTER
))
styles.add(ParagraphStyle(
    name='TableCell', fontName='Helvetica', fontSize=8.5,
    leading=11, textColor=DARK_GREY
))
styles.add(ParagraphStyle(
    name='TableCellBold', fontName='Helvetica-Bold', fontSize=8.5,
    leading=11, textColor=DARK_GREY
))
styles.add(ParagraphStyle(
    name='StatusConfirmed', fontName='Helvetica-Bold', fontSize=8,
    leading=10, textColor=GREEN
))
styles.add(ParagraphStyle(
    name='StatusMissing', fontName='Helvetica-Bold', fontSize=8,
    leading=10, textColor=RED
))
styles.add(ParagraphStyle(
    name='RiskKritis', fontName='Helvetica-Bold', fontSize=8.5,
    leading=11, textColor=RED
))
styles.add(ParagraphStyle(
    name='RiskTinggi', fontName='Helvetica-Bold', fontSize=8.5,
    leading=11, textColor=ORANGE
))

# ──────────────────────────────────────────────
# Helper: risk span
# ──────────────────────────────────────────────
def risk_tag(level, text):
    if level == "KRITIS":
        return f'<font color="#C0392B"><b>🔴 {text}</b></font>'
    elif level == "TINGGI":
        return f'<font color="#E67E22"><b>🟡 {text}</b></font>'
    elif level == "SEDANG":
        return f'<font color="#F39C12"><b>🟠 {text}</b></font>'
    else:
        return f'<font color="#27AE60"><b>🟢 {text}</b></font>'

def status_badge(status):
    if "Confirmed" in status:
        return f'<font color="#27AE60"><b>{status}</b></font>'
    else:
        return f'<font color="#C0392B"><b>{status}</b></font>'

# ──────────────────────────────────────────────
# Header / Footer
# ──────────────────────────────────────────────
def header_footer(canvas, doc):
    canvas.saveState()
    w, h = A4

    # Header bar
    canvas.setFillColor(NAVY)
    canvas.rect(0, h - 22*mm, w, 22*mm, fill=1, stroke=0)

    canvas.setFillColor(white)
    canvas.setFont("Helvetica-Bold", 10)
    canvas.drawString(15*mm, h - 15*mm, "SARFlow — SISTEM OPERASI SAR")

    canvas.setFont("Helvetica", 8)
    canvas.drawString(15*mm, h - 19*mm, "Laporan Operasi SAR | INS-20260515-006")

    # SAR emblem mock
    canvas.setFillColor(HexColor("#F5B041"))
    canvas.setFont("Helvetica-Bold", 14)
    canvas.drawRightString(w - 15*mm, h - 16*mm, "SAR")

    # Footer bar
    canvas.setFillColor(LIGHT_GREY)
    canvas.rect(0, 0, w, 14*mm, fill=1, stroke=0)

    canvas.setFillColor(MED_GREY)
    canvas.setFont("Helvetica", 7)
    canvas.drawString(15*mm, 5*mm, "⚠️ DRAFT ADMINISTRATIF — BUKAN PERNYATAAN PUBLIK RESMI")
    canvas.drawString(15*mm, 2*mm, "⚠️ Belum terverifikasi — perlu konfirmasi petugas.")

    canvas.setFont("Helvetica", 7)
    canvas.drawRightString(w - 15*mm, 5*mm, f"Halaman {doc.page}")
    canvas.drawRightString(w - 15*mm, 2*mm, f"Cetak: {datetime.now().strftime('%d %b %Y %H:%M')} UTC")

    canvas.restoreState()


# ──────────────────────────────────────────────
# Build document
# ──────────────────────────────────────────────
OUTPUT_PATH = "/app/working/workspaces/report_generator_agent/output/INS-20260515-006_laporan_20260515.pdf"

doc = SimpleDocTemplate(
    OUTPUT_PATH,
    pagesize=A4,
    leftMargin=20*mm,
    rightMargin=20*mm,
    topMargin=30*mm,
    bottomMargin=22*mm,
    title="Laporan Operasi SAR - INS-20260515-006",
    author="Report Generator Agent - SARFlow",
    subject="2 Pendaki Hilang Gunung Merbabu"
)

story = []

# ==================== PAGE 1: COVER ====================
# Dark cover page
cover_data = [
    Paragraph("SARFlow", styles['CoverTitle']),
    Paragraph("SISTEM OPERASI SAR", styles['CoverSub']),
    Spacer(1, 10*mm),
    HRFlowable(width="80%", thickness=1, color=HexColor("#F5B041")),
    Spacer(1, 8*mm),
    Paragraph("LAPORAN OPERASI SAR", ParagraphStyle(
        'CoverTitleBig', fontName='Helvetica-Bold', fontSize=20,
        leading=26, textColor=white, alignment=TA_CENTER, spaceAfter=4*mm
    )),
    Spacer(1, 4*mm),
    Paragraph("2 Pendaki Hilang", ParagraphStyle(
        'CoverCase', fontName='Helvetica-Bold', fontSize=16,
        leading=20, textColor=HexColor("#F5B041"), alignment=TA_CENTER, spaceAfter=2*mm
    )),
    Paragraph("Gunung Merbabu", styles['CoverSub']),
    Spacer(1, 6*mm),
    HRFlowable(width="60%", thickness=0.5, color=HexColor("#7F8C8D")),
    Spacer(1, 6*mm),
    Paragraph("ID Laporan: DRAFT-SAR/2026/INS-006/v1.0", styles['CoverInfo']),
    Paragraph("Tanggal: 15 Mei 2026", styles['CoverInfo']),
    Paragraph("Status: DRAFT — Belum terverifikasi", styles['CoverInfo']),
    Spacer(1, 12*mm),
    Paragraph("⚠️ DOKUMEN ADMINISTRATIF — BUKAN INSTRUKSI LAPANGAN", ParagraphStyle(
        'CoverDisclaimer', fontName='Helvetica-Bold', fontSize=9,
        leading=12, textColor=RED, alignment=TA_CENTER
    )),
    PageBreak(),
]

# Build cover with custom background (cannot embed in SimpleDocTemplate easily)
# So we'll just add the cover content on page 1 with header/footer suppressed.
# Simple approach: prepend cover data then use a custom page template... 
# Actually easier: Just add the cover as normal content with a different look.

# I'll create a custom frame-based approach. But simplest: just add cover as-is
# and let header/footer appear from page 2 onward.

# Actually let me use a simpler approach — just add content directly.

story = []
# We'll handle cover via a special approach — use a Table as full-page background
# Simple: just add cover content before PageBreak

# Cover
cover_style = ParagraphStyle('CoverTitle2', fontName='Helvetica-Bold', fontSize=24,
    leading=30, textColor=NAVY, alignment=TA_CENTER, spaceAfter=2*mm)

story.append(Spacer(1, 30*mm))
story.append(Paragraph("SARFlow", ParagraphStyle('CoverBrand', fontName='Helvetica-Bold',
    fontSize=28, leading=34, textColor=NAVY, alignment=TA_CENTER)))
story.append(Paragraph("SISTEM OPERASI SAR", ParagraphStyle('CoverBrandSub',
    fontName='Helvetica', fontSize=11, leading=14, textColor=MED_GREY, alignment=TA_CENTER)))
story.append(Spacer(1, 15*mm))
story.append(HRFlowable(width="60%", thickness=1.5, color=NAVY))
story.append(Spacer(1, 10*mm))
story.append(Paragraph("LAPORAN OPERASI SAR", ParagraphStyle('CoverH1',
    fontName='Helvetica-Bold', fontSize=20, leading=26, textColor=DARK_RED, alignment=TA_CENTER)))
story.append(Spacer(1, 5*mm))
story.append(Paragraph("2 Pendaki Hilang", ParagraphStyle('CoverH2',
    fontName='Helvetica-Bold', fontSize=18, leading=22, textColor=DARK_GREY, alignment=TA_CENTER)))
story.append(Paragraph("Gunung Merbabu", ParagraphStyle('CoverH2Sub',
    fontName='Helvetica', fontSize=14, leading=18, textColor=MED_GREY, alignment=TA_CENTER)))
story.append(Spacer(1, 12*mm))
story.append(HRFlowable(width="40%", thickness=0.5, color=LIGHT_GREY))
story.append(Spacer(1, 8*mm))

cover_info = [
    ["ID Laporan:", "DRAFT-SAR/2026/INS-006/v1.0"],
    ["Tanggal Kejadian:", "15 Mei 2026"],
    ["Lokasi:", "Gunung Merbabu — Jalur Selo / Wekas"],
    ["Status:", "DRAFT — Belum terverifikasi"],
]
cover_table = Table(cover_info, colWidths=[50*mm, 100*mm])
cover_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
    ('FONTNAME', (1,0), (1,-1), 'Helvetica'),
    ('FONTSIZE', (0,0), (-1,-1), 9.5),
    ('TEXTCOLOR', (0,0), (-1,-1), DARK_GREY),
    ('ALIGN', (0,0), (0,-1), 'RIGHT'),
    ('ALIGN', (1,0), (1,-1), 'LEFT'),
    ('TOPPADDING', (0,0), (-1,-1), 3),
    ('BOTTOMPADDING', (0,0), (-1,-1), 3),
    ('RIGHTPADDING', (0,0), (0,-1), 8),
]))
story.append(cover_table)

story.append(Spacer(1, 25*mm))
story.append(HRFlowable(width="100%", thickness=0.5, color=LIGHT_GREY))
story.append(Spacer(1, 3*mm))
story.append(Paragraph(
    "⚠️ <b>DRAFT ADMINISTRATIF — BUKAN PERNYATAAN PUBLIK RESMI</b>",
    ParagraphStyle('DisclaimerCover', fontName='Helvetica', fontSize=8,
        leading=11, textColor=RED, alignment=TA_CENTER)
))
story.append(Paragraph(
    "⚠️ <b>Belum terverifikasi — perlu konfirmasi petugas.</b>",
    ParagraphStyle('DisclaimerCover2', fontName='Helvetica', fontSize=8,
        leading=11, textColor=RED, alignment=TA_CENTER)
))
story.append(Paragraph(
    "Bukan instruksi lapangan. Keputusan operasional ada di tangan KOM.",
    ParagraphStyle('DisclaimerCover3', fontName='Helvetica', fontSize=7.5,
        leading=10, textColor=MED_GREY, alignment=TA_CENTER)
))

story.append(PageBreak())

# ==================== PAGE 2+: MAIN CONTENT ====================

# ── I. IDENTITAS LAPORAN ──
story.append(Paragraph("I. IDENTITAS LAPORAN", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

identitas_data = [
    ["Nomor Laporan", ":", "DRAFT-SAR/2026/INS-006/v1.0"],
    ["Jenis Kejadian", ":", "Pendaki Hilang (Missing Person — Mountain)"],
    ["Lokasi", ":", "Gunung Merbabu — Naik via jalur Selo, rencana turun via Wekas"],
    ["Kabupaten", ":", "Boyolali / Magelang / Semarang, Jawa Tengah"],
    ["Tanggal Kejadian", ":", "15 Mei 2026"],
    ["Status", ":", "DRAFT — Belum terverifikasi"],
]

idt = Table(identitas_data, colWidths=[38*mm, 5*mm, 112*mm])
idt.setStyle(TableStyle([
    ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
    ('FONTNAME', (1,0), (1,-1), 'Helvetica'),
    ('FONTNAME', (2,0), (2,-1), 'Helvetica'),
    ('FONTSIZE', (0,0), (-1,-1), 9),
    ('TEXTCOLOR', (0,0), (-1,-1), DARK_GREY),
    ('ALIGN', (0,0), (0,-1), 'LEFT'),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ('TOPPADDING', (0,0), (-1,-1), 1.5),
    ('BOTTOMPADDING', (0,0), (-1,-1), 1.5),
    ('LEFTPADDING', (1,0), (1,-1), 2),
]))
story.append(idt)
story.append(Spacer(1, 4*mm))

# ── II. DATA KORBAN ──
story.append(Paragraph("II. DATA KORBAN", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

korban_header = [Paragraph("<b>No</b>", styles['TableCellBold']),
                 Paragraph("<b>Data</b>", styles['TableCellBold']),
                 Paragraph("<b>Status</b>", styles['TableCellBold'])]

korban_rows = [
    ["1", "Jumlah korban: 2 orang (laki-laki)", status_badge("✅ Confirmed")],
    ["2", "Jaket merah (1 orang)", status_badge("✅ Confirmed")],
    ["3", "Jaket biru (1 orang)", status_badge("✅ Confirmed")],
    ["4", "Nama korban", status_badge("❌ Missing — perlu konfirmasi")],
    ["5", "Usia", status_badge("❌ Missing")],
    ["6", "Perlengkapan (headlamp, raincoat, sleeping bag, logistik)", status_badge("❌ Missing")],
]

korban_data = [korban_header] + korban_rows
korban_table = Table(korban_data, colWidths=[10*mm, 100*mm, 45*mm])
korban_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 8.5),
    ('BACKGROUND', (0,0), (-1,0), NAVY),
    ('TEXTCOLOR', (0,0), (-1,0), white),
    ('ALIGN', (0,0), (0,-1), 'CENTER'),
    ('ALIGN', (2,0), (2,-1), 'CENTER'),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor("#F8F9FA")]),
    ('TOPPADDING', (0,0), (-1,-1), 4),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
]))
story.append(korban_table)
story.append(Spacer(1, 4*mm))

# ── III. DATA PELAPOR ──
story.append(Paragraph("III. DATA PELAPOR", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

pelapor_data = [
    ["Nama", ":", "Andi"],
    ["Peran", ":", "Ketua Rombongan"],
    ["Kontak", ":", "085712345678"],
    ["Status", ":", status_badge("✅ Confirmed")],
]
plt = Table(pelapor_data, colWidths=[25*mm, 5*mm, 125*mm])
plt.setStyle(TableStyle([
    ('FONTNAME', (0,0), (0,-1), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 9),
    ('TEXTCOLOR', (0,0), (-1,-1), DARK_GREY),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ('TOPPADDING', (0,0), (-1,-1), 1.5),
    ('BOTTOMPADDING', (0,0), (-1,-1), 1.5),
    ('LEFTPADDING', (1,0), (1,-1), 2),
]))
story.append(plt)
story.append(Spacer(1, 4*mm))

# ── IV. KRONOLOGI ──
story.append(Paragraph("IV. KRONOLOGI", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

kron_header = [Paragraph("<b>Waktu (WIB)</b>", styles['TableCellBold']),
               Paragraph("<b>Kejadian</b>", styles['TableCellBold'])]
kron_rows = [
    ["15 Mei 2026\n14.00 WIB",
     "Kontak terakhir dengan kedua pendaki. Mereka menyampaikan akan turun via Wekas. Cuaca gerimis dan kabut."],
    ["15 Mei 2026\n17.00 WIB",
     "Dilaporkan oleh Andi (ketua rombongan) bahwa kedua pendaki belum kembali hingga jam 5 sore."],
    ["15 Mei 2026\n23.00+ WIB",
     "Kondisi malam: cuaca memburuk, hujan ringan, kabut tebal. Suhu diperkirakan 10-15°C dengan wind chill 3-8°C."],
]
kron_data = [kron_header] + kron_rows
kron_table = Table(kron_data, colWidths=[35*mm, 120*mm])
kron_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 8.5),
    ('BACKGROUND', (0,0), (-1,0), NAVY),
    ('TEXTCOLOR', (0,0), (-1,0), white),
    ('ALIGN', (0,0), (0,-1), 'CENTER'),
    ('VALIGN', (0,0), (-1,-1), 'TOP'),
    ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor("#F8F9FA")]),
    ('TOPPADDING', (0,0), (-1,-1), 5),
    ('BOTTOMPADDING', (0,0), (-1,-1), 5),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
]))
story.append(kron_table)
story.append(Spacer(1, 4*mm))

# ── V. KONDISI LAPANGAN & CUACA ──
story.append(Paragraph("V. KONDISI LAPANGAN & CUACA", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

cuaca_data = [
    [Paragraph("<b>Aspek</b>", styles['TableCellBold']),
     Paragraph("<b>Keterangan</b>", styles['TableCellBold'])],
    ["Cuaca saat kontak terakhir", "Gerimis, kabut"],
    ["Cuaca terkini", "Berawan / hujan ringan (BMKG)"],
    ["Prakiraan", "Hujan dengan probabilitas 87-100% (BMKG)"],
    ["Suhu ketinggian", "10-15°C, wind chill 3-8°C"],
    ["Risiko hipotermia", risk_tag("KRITIS", "Tinggi")],
    ["Jalur Wekas", "Lebih curam, licin saat hujan"],
    ["Visibilitas", "Sangat terbatas akibat kabut tebal"],
]

cuaca_table = Table(cuaca_data, colWidths=[50*mm, 105*mm])
cuaca_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 8.5),
    ('BACKGROUND', (0,0), (-1,0), NAVY),
    ('TEXTCOLOR', (0,0), (-1,0), white),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor("#F8F9FA")]),
    ('TOPPADDING', (0,0), (-1,-1), 4),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
]))
story.append(cuaca_table)
story.append(Spacer(1, 4*mm))

# ── VI. ANALISIS RISIKO — RED FLAGS ──
story.append(Paragraph("VI. ANALISIS RISIKO — RED FLAGS", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

red_header = [Paragraph("<b>No</b>", styles['TableCellBold']),
              Paragraph("<b>Risiko</b>", styles['TableCellBold']),
              Paragraph("<b>Level</b>", styles['TableCellBold'])]

red_rows = [
    ["1", "Hipotermia (suhu rendah + gerimis + kabut)", risk_tag("KRITIS", "KRITIS")],
    ["2", "Malam hari + kabut tebal (visibilitas nol)", risk_tag("KRITIS", "KRITIS")],
    ["3", "Cuaca ekstrem BMKG (hujan lebat + petir hingga dini hari)", risk_tag("KRITIS", "KRITIS")],
    ["4", "9+ jam tanpa kontak — golden window lewat", risk_tag("KRITIS", "KRITIS")],
    ["5", "Jalur turun berbeda (Selo→Wekas) — tidak familiar", risk_tag("TINGGI", "TINGGI")],
    ["6", "Jalur Wekas curam, licin (risiko terpeleset/cedera)", risk_tag("TINGGI", "TINGGI")],
    ["7", "Tanpa informasi perlengkapan", risk_tag("TINGGI", "TINGGI")],
    ["8", "Nama korban belum diketahui (sulit dipanggil)", risk_tag("TINGGI", "TINGGI")],
]

red_data = [red_header] + red_rows
red_table = Table(red_data, colWidths=[10*mm, 110*mm, 35*mm])
red_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 8.5),
    ('BACKGROUND', (0,0), (-1,0), NAVY),
    ('TEXTCOLOR', (0,0), (-1,0), white),
    ('ALIGN', (0,0), (0,-1), 'CENTER'),
    ('ALIGN', (2,0), (2,-1), 'CENTER'),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor("#F8F9FA")]),
    ('TOPPADDING', (0,0), (-1,-1), 4),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
]))
story.append(red_table)
story.append(Spacer(1, 4*mm))

# ── VII. REKOMENDASI ──
story.append(Paragraph("VII. REKOMENDASI", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

story.append(Paragraph("<b>Segera (Malam Ini):</b>", styles['SubTitle']))
rekom_segera = [
    "1. Koordinasi dengan Balai Taman Nasional Gunung Merbabu",
    "2. Hubungi Basecamp Selo & Basecamp Wekas — cek registrasi pendaki",
    "3. Konfirmasi nama & perlengkapan ke Andi (085712345678)",
]
for r in rekom_segera:
    story.append(Paragraph(r, styles['BodyText2']))

story.append(Paragraph("<b>Subuh:</b>", styles['SubTitle']))
rekom_subuh = [
    "4. Siapkan tim reaksi cepat",
    "5. Kirim tim pencarian via jalur Selo dan Wekas",
    "6. Koordinasi dengan BPBD Boyolali/Magelang",
]
for r in rekom_subuh:
    story.append(Paragraph(r, styles['BodyText2']))

story.append(Paragraph("<b>Lanjutan:</b>", styles['SubTitle']))
rekom_lanjut = [
    "7. Update data korban setelah nama diketahui",
    "8. Siapkan logistik untuk tim dan korban",
]
for r in rekom_lanjut:
    story.append(Paragraph(r, styles['BodyText2']))

story.append(Spacer(1, 4*mm))

# ── VIII. DATA MISSING TRACKER ──
story.append(Paragraph("VIII. DATA MISSING TRACKER", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

mt_header = [Paragraph("<b>Item</b>", styles['TableCellBold']),
             Paragraph("<b>Prioritas</b>", styles['TableCellBold'])]

mt_rows = [
    ["Nama korban (2 orang)", risk_tag("KRITIS", "KRITIS")],
    ["Perlengkapan yang dibawa", risk_tag("TINGGI", "TINGGI")],
    ["Titik koordinat / basecamp terakhir", risk_tag("TINGGI", "TINGGI")],
    ["Usia korban", risk_tag("SEDANG", "SEDANG")],
    ["Kondisi kesehatan korban", risk_tag("SEDANG", "SEDANG")],
    ["Nomor HP korban", risk_tag("SEDANG", "SEDANG")],
    ["Riwayat pendakian/pengalaman", risk_tag("RENDAH", "RENDAH")],
]

mt_data = [mt_header] + mt_rows
mt_table = Table(mt_data, colWidths=[100*mm, 55*mm])
mt_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 8.5),
    ('BACKGROUND', (0,0), (-1,0), NAVY),
    ('TEXTCOLOR', (0,0), (-1,0), white),
    ('ALIGN', (2,0), (2,-1), 'CENTER'),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor("#F8F9FA")]),
    ('TOPPADDING', (0,0), (-1,-1), 4),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
]))
story.append(mt_table)
story.append(Spacer(1, 6*mm))

# ── IX. STATUS ──
story.append(Paragraph("IX. STATUS", styles['SectionTitle']))
story.append(HRFlowable(width="100%", thickness=1, color=NAVY))
story.append(Spacer(1, 2*mm))

status_data = [
    [Paragraph("<b>Aspek</b>", styles['TableCellBold']),
     Paragraph("<b>Informasi</b>", styles['TableCellBold'])],
    ["Hari ke-", "1"],
    ["Status Operasi", "BRIEFING_COMPLETED — Menunggu eksekusi KOM"],
    ["Golden period tersisa", "±14,5 jam"],
]
st_table = Table(status_data, colWidths=[50*mm, 105*mm])
st_table.setStyle(TableStyle([
    ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
    ('FONTSIZE', (0,0), (-1,-1), 9),
    ('BACKGROUND', (0,0), (-1,0), NAVY),
    ('TEXTCOLOR', (0,0), (-1,0), white),
    ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
    ('GRID', (0,0), (-1,-1), 0.5, LIGHT_GREY),
    ('ROWBACKGROUNDS', (0,1), (-1,-1), [white, HexColor("#F8F9FA")]),
    ('TOPPADDING', (0,0), (-1,-1), 4),
    ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ('LEFTPADDING', (0,0), (-1,-1), 6),
    ('RIGHTPADDING', (0,0), (-1,-1), 6),
]))
story.append(st_table)
story.append(Spacer(1, 8*mm))

# ── DISCLAIMER ──
story.append(HRFlowable(width="100%", thickness=1.5, color=RED))
story.append(Spacer(1, 3*mm))
story.append(Paragraph(
    "⚠️ <b>DRAFT ADMINISTRATIF — BUKAN PERNYATAAN PUBLIK RESMI</b>",
    styles['DisclaimerStyle']
))
story.append(Paragraph(
    "⚠️ <b>Belum terverifikasi — perlu konfirmasi petugas.</b>",
    styles['DisclaimerStyle']
))
story.append(Paragraph(
    "Dokumen ini bersifat administratif. Bukan instruksi lapangan. "
    "Keputusan operasional ada di tangan Komandan Operasi SAR (KOM).",
    ParagraphStyle('DisclaimerBody', fontName='Helvetica', fontSize=8,
        leading=11, textColor=DARK_GREY, alignment=TA_CENTER, spaceAfter=2*mm)
))

# Build
doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
print(f"✅ PDF berhasil dibuat: {OUTPUT_PATH}")
